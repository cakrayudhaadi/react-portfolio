import { useState, useEffect } from "react";
import emailjs from 'emailjs-com';

import Contact from "./components/Contact/Contact.jsx";

const style = `
  @import url('https://fonts.googleapis.com/css2?family=Press+Start+2P&family=Lato:wght@300;400;700&family=Crimson+Pro:ital,wght@0,400;0,600;1,400&display=swap');

  :root {
    --dark:     #2E3A2F;
    --deep:     #3B4D3C;
    --hay:      #D4A843;
    --wheat:    #E8C96A;
    --grass:    #4A7C3F;
    --leaf:     #6BAB5E;
    --sage:     #8FBC6E;
    --moss:     #3D5E35;
    --sky:      #B8D4E8;
    --cream:    #F9F5EC;
    --offwhite: #F4EFE3;
    --ivory:    #EDE8DC;
    --stone:    #B0A898;
    --muted:    #7A7264;
    --berry:    #8B3A52;
    --sun:      #F0A830;
    --water:    #5B8FA8;
    --fog:      rgba(249,245,236,0.93);
  }

  * { box-sizing:border-box; margin:0; padding:0; }
  html, body { width:100%; min-height:100%; }
  html { scroll-behavior:smooth; }

  body {
    font-family:'Lato',sans-serif;
    background-color:var(--cream);
    color:var(--dark);
    overflow-x:hidden;
    min-height:100vh;
  }

  body::before {
    content:''; position:fixed; top:0; left:0; width:100%; height:100%;
    background-image:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(46,58,47,0.025) 2px,rgba(46,58,47,0.025) 4px);
    pointer-events:none; z-index:9999;
  }

  /* NAV */
  nav {
    position:sticky; top:0; z-index:1000;
    background:var(--dark); border-bottom:3px solid var(--hay);
    padding:0 2rem; display:flex; align-items:center; justify-content:space-between;
    height:60px; box-shadow:0 4px 20px rgba(0,0,0,0.25);
  }
  .nav-logo { font-family:'Press Start 2P',monospace; font-size:14px; color:var(--hay); letter-spacing:1px; line-height:1.6; }
  .nav-links { display:flex; gap:0.4rem; list-style:none; }
  .nav-links a {
    font-family:'Press Start 2P',monospace; font-size:6.5px; color:var(--ivory);
    text-decoration:none; padding:6px 10px; border:2px solid transparent;
    border-radius:20px; transition:all 0.15s; letter-spacing:0.5px;
  }
  .nav-links a:hover, .nav-links a.active { color:var(--hay); border-color:var(--hay); background:rgba(212,168,67,0.1); }

  /* HERO */
  .hero {
    min-height:100vh;
    background:linear-gradient(180deg,#A8C8E0 0%,#BDD5E5 22%,#8FBC6E 58%,#6BAB5E 68%,#4A7C3F 78%,#3D5E35 100%);
    position:relative; overflow:hidden; display:flex; align-items:center; justify-content:center;
  }
  .hero-sun {
    position:absolute; top:55px; right:14%; width:96px; height:96px;
    background:radial-gradient(circle,#FFE066 30%,#F0A830 60%,transparent 75%);
    border-radius:50%; box-shadow:0 0 60px 30px rgba(240,168,48,0.3);
    animation:sunPulse 4s ease-in-out infinite;
  }
  @keyframes sunPulse {
    0%,100%{transform:scale(1);box-shadow:0 0 60px 30px rgba(240,168,48,0.3);}
    50%{transform:scale(1.05);box-shadow:0 0 80px 40px rgba(240,168,48,0.4);}
  }
  .cloud { position:absolute; background:rgba(255,255,255,0.88); border-radius:50px; animation:drift linear infinite; }
  @keyframes drift { from{transform:translateX(-250px);} to{transform:translateX(110vw);} }
  .tree { position:absolute; bottom:0; display:flex; flex-direction:column; align-items:center; }
  .tree-top { width:0; height:0; border-left:solid transparent; border-right:solid transparent; border-bottom:solid #3D5E35; filter:drop-shadow(2px 2px 0 rgba(0,0,0,0.2)); }
  .tree-trunk { background:#6B4A2A; border:2px solid #4a3018; }

  .hero-content { position:relative; z-index:10; text-align:center; padding:2rem; margin-top:-6vh; }
  .hero-card {
    background:var(--fog); border:2px solid rgba(255,255,255,0.7);
    border-radius:28px; padding:3rem 4rem;
    box-shadow:0 16px 56px rgba(46,58,47,0.16),0 2px 0 rgba(255,255,255,0.9) inset;
    backdrop-filter:blur(10px); position:relative; animation:fadeInUp 0.8s ease both;
  }
  @keyframes fadeInUp { from{opacity:0;transform:translateY(30px);} to{opacity:1;transform:translateY(0);} }
  .hero-card::before {
    content:'✦'; position:absolute; top:-14px; left:50%; transform:translateX(-50%);
    font-size:14px; color:var(--hay); background:var(--dark); padding:0 8px;
    width:28px; height:28px; border-radius:50%;
    display:flex; align-items:center; justify-content:center; line-height:28px;
  }
  .hero-tag { font-family:'Press Start 2P',monospace; font-size:7.5px; color:var(--grass); letter-spacing:3px; display:block; margin-bottom:1rem; }
  .hero-name { font-family:'Press Start 2P',monospace; font-size:clamp(13px,2.4vw,21px); color:var(--dark); line-height:1.9; margin-bottom:0.5rem; text-shadow:2px 2px 0 rgba(212,168,67,0.3); }
  .hero-role { font-family:'Crimson Pro',serif; font-size:1.55rem; color:var(--berry); font-style:italic; margin-bottom:1.5rem; }
  .hero-summary { font-size:1rem; color:var(--muted); max-width:540px; line-height:1.85; margin:0 auto 2rem; }
  .hero-btns { display:flex; gap:1rem; justify-content:center; flex-wrap:wrap; }

  .btn { font-family:'Press Start 2P',monospace; font-size:7.5px; padding:12px 22px; border-radius:50px; cursor:pointer; text-decoration:none; transition:all 0.15s; display:inline-flex; align-items:center; gap:8px; letter-spacing:0.5px; }
  .btn:active{transform:scale(0.97);}
  .btn-primary { background:var(--sky); color:var(--water); border:2px solid var(--water); box-shadow:0 4px 18px rgba(113, 153, 198, 0.35); }
  .btn-primary:hover { background:var(--water); color:var(--cream); box-shadow:0 6px 24px rgba(88, 99, 201, 0.45); }
  .btn-secondary { background:var(--grass); color:var(--cream); border:2px solid var(--moss); box-shadow:0 4px 18px rgba(74,124,63,0.35); }
  .btn-secondary:hover { background:var(--moss); box-shadow:0 6px 24px rgba(74,124,63,0.45); }
  .btn-tertiary { background:rgba(232, 201, 106, 0.2); color:var(--dark); border:2px solid var(--stone); box-shadow:0 4px 12px rgba(0,0,0,0.08); }
  .btn-tertiary:hover { background:var(--hay); border-color:var(--hay); }

  .scroll-hint {
    position:absolute; bottom:28px; left:50%; transform:translateX(-50%);
    font-family:'Press Start 2P',monospace; font-size:6.5px; color:var(--cream);
    animation:bounce 1.5s ease-in-out infinite; z-index:10;
    display:flex; flex-direction:column; align-items:center; gap:6px;
    text-shadow:1px 1px 2px rgba(0,0,0,0.4);
  }
  @keyframes bounce { 0%,100%{transform:translateX(-50%) translateY(0);} 50%{transform:translateX(-50%) translateY(8px);} }

  /* SECTIONS */
  section { padding:5rem 2rem; max-width:1100px; margin:0 auto; }
  .section-inner { max-width:1100px; margin:0 auto; padding:0 2rem; }
  .section-header { text-align:center; margin-bottom:3rem; }
  .section-label { font-family:'Press Start 2P',monospace; font-size:8px; color:var(--dark); letter-spacing:4px; display:block; margin-bottom:0.75rem; }
  .section-title { font-family:'Press Start 2P',monospace; font-size:clamp(13px,1.9vw,19px); color:var(--dark); line-height:2; position:relative; display:inline-block; }
  .section-title::after { content:''; position:absolute; bottom:-8px; left:0; right:0; height:3px; background:linear-gradient(90deg,var(--hay),var(--grass),var(--hay)); border-radius:2px; }

  /* DIVIDER */
  .field-divider { width:100%; height:72px; background:linear-gradient(180deg,var(--sage) 0%,var(--grass) 50%,var(--dark) 100%); position:relative; overflow:hidden; }
  .field-divider::before { content:'🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾🌾'; position:absolute; bottom:0; font-size:26px; white-space:nowrap; letter-spacing:-4px; animation:swayField 3s ease-in-out infinite; line-height:1; }
  @keyframes swayField { 0%,100%{transform:rotate(-2deg);} 50%{transform:rotate(2deg);} }

  /* ABOUT */
  .about-grid { display:grid; grid-template-columns:1fr 1.5fr; gap:3rem; align-items:start; }
  .about-card { background:var(--offwhite); border:1.5px solid var(--ivory); border-radius:24px; padding:2rem; box-shadow:0 4px 24px rgba(46,58,47,0.07); }
  .avatar-frame { width:128px; height:128px; margin:0 auto 1.5rem; border:2px solid var(--ivory); border-radius:20px; background:linear-gradient(135deg,var(--sky) 0%,var(--sage) 100%); display:flex; align-items:center; justify-content:center; font-size:58px; box-shadow:0 6px 20px rgba(74,124,63,0.18); position:relative; overflow:hidden; }
  .avatar-frame::after { content:''; position:absolute; bottom:0; left:0; right:0; height:35%; background:var(--grass); clip-path:polygon(0 60%,10% 30%,20% 55%,30% 20%,40% 50%,50% 15%,60% 45%,70% 25%,80% 55%,90% 30%,100% 50%,100% 100%,0 100%); }
  .about-name-card { text-align:center; margin-bottom:1.5rem; }
  .about-name-card h2 { font-family:'Press Start 2P',monospace; font-size:12px; color:var(--dark); margin-bottom:0.5rem; line-height:1.9; }
  .about-name-card p { font-family:'Crimson Pro',serif; font-style:italic; color:var(--berry); font-size:1.1rem; }
  .stat-list { list-style:none; display:flex; flex-direction:column; gap:0.65rem; }
  .stat-item { display:flex; align-items:center; gap:0.75rem; font-size:0.875rem; color:var(--muted); }
  .stat-icon { font-size:17px; width:26px; text-align:center; flex-shrink:0; }
  .stat-item a { color:var(--grass); text-decoration:none; font-weight:700; }
  .stat-item a:hover { color:var(--moss); text-decoration:underline; }
  .about-text p { font-size:1.05rem; line-height:1.9; color:var(--muted); margin-bottom:1.2rem; }
  .about-text strong { color:var(--dark); }

  .xp-bars { margin-top:2rem; }
  .xp-label { font-family:'Press Start 2P',monospace; font-size:10px; color:var(--dark); margin-bottom:1rem; display:block; }
  .xp-row { display:flex; align-items:center; gap:1rem; margin-bottom:0.7rem; }
  .xp-name { font-size:0.82rem; color:var(--muted); width:120px; flex-shrink:0; font-weight:700; }
  .xp-track { flex:1; height:10px; background:var(--ivory); border:1.5px solid var(--stone); border-radius:20px; overflow:hidden; }
  .xp-fill { height:100%; background:linear-gradient(90deg,var(--grass),var(--leaf)); border-radius:20px; animation:shimmer 3s linear infinite; }
  @keyframes shimmer { 0%{filter:brightness(1);} 50%{filter:brightness(1.15);} 100%{filter:brightness(1);} }
  .xp-pct { font-family:'Press Start 2P',monospace; font-size:6.5px; color:var(--grass); width:28px; text-align:right; }

  /* SKILLS */
  .skills-bg { background:var(--offwhite); padding:5rem 0; }
  .skill-category-title { font-family:'Press Start 2P',monospace; font-size:8px; color:var(--cream); background:var(--deep); display:inline-block; padding:6px 16px; border-radius:20px; margin:2.5rem 0 1.25rem; letter-spacing:1px; }
  .skills-row { display:flex; flex-wrap:wrap; gap:0.85rem; align-items:center; }
  .skill-pill { display:flex; align-items:center; gap:10px; padding:8px 18px 8px 12px; border-radius:50px; background:var(--cream); border:1.5px solid var(--ivory); box-shadow:0 2px 8px rgba(46,58,47,0.06); transition:all 0.18s; cursor:default; }
  .skill-pill:hover { transform:translateY(-3px); box-shadow:0 8px 20px rgba(74,124,63,0.14); border-color:var(--sage); background:#fff; }
  .skill-pill img { width:28px; height:28px; object-fit:contain; display:block; flex-shrink:0; }
  .skill-pill-name { font-family:'Lato',sans-serif; font-weight:700; font-size:0.82rem; color:var(--dark); white-space:nowrap; }

  /* EXPERIENCE */
  .exp-bg { background:var(--dark); padding:5rem 0; }
  .exp-bg .section-label { color:var(--stone); }
  .exp-bg .section-title { color:var(--hay); }
  .exp-bg .section-title::after { background:linear-gradient(90deg,var(--hay),var(--sage),var(--hay)); }
  .timeline { position:relative; padding-left:3rem; }
  .timeline::before { content:''; position:absolute; left:11px; top:0; bottom:0; width:3px; background:repeating-linear-gradient(180deg,var(--hay) 0px,var(--hay) 8px,transparent 8px,transparent 14px); }
  .company-block { margin-bottom:2.75rem; }
  .company-header { background:rgba(255,255,255,0.06); border:1.5px solid rgba(212,168,67,0.4); border-radius:18px; padding:1.1rem 1.5rem; margin-bottom:1rem; position:relative; box-shadow:0 4px 16px rgba(0,0,0,0.18); backdrop-filter:blur(4px); }
  .company-header::before { content:'⬥'; position:absolute; left:-38px; top:50%; transform:translateY(-50%); font-size:16px; color:var(--hay); width:26px; height:26px; background:var(--dark); border:2px solid var(--hay); border-radius:50%; display:flex; align-items:center; justify-content:center; line-height:22px; text-align:center; }
  .company-name { font-family:'Press Start 2P',monospace; font-size:8.5px; color:var(--hay); margin-bottom:0.35rem; line-height:1.7; }
  .company-period { font-size:0.8rem; color:var(--sage); font-style:italic; }
  .role-cards { display:flex; flex-direction:column; gap:0.85rem; padding-left:0.75rem; }
  .role-card { background:rgba(255,255,255,0.05); border:1.5px solid rgba(255,255,255,0.09); border-radius:16px; padding:1.2rem 1.5rem; transition:all 0.2s; }
  .role-card:hover { border-color:rgba(212,168,67,0.45); background:rgba(255,255,255,0.08); transform:translateX(4px); }
  .role-title { font-family:'Press Start 2P',monospace; font-size:7.5px; color:#E8E0D0; margin-bottom:0.3rem; line-height:1.7; }
  .role-client { font-size:0.8rem; color:var(--sage); margin-bottom:0.75rem; font-style:italic; }
  .role-bullets { list-style:none; display:flex; flex-direction:column; gap:0.5rem; }
  .role-bullets li { font-size:0.875rem; color:rgba(232,224,208,0.8); line-height:1.75; padding-left:1.1rem; position:relative; }
  .role-bullets li::before { content:'▸'; position:absolute; left:0; color:var(--hay); }
  .tech-tags { display:flex; flex-wrap:wrap; gap:0.4rem; margin-top:0.75rem; }
  .tech-tag { font-family:'Press Start 2P',monospace; font-size:5.5px; padding:4px 10px; background:rgba(212,168,67,0.1); border:1px solid rgba(212,168,67,0.3); border-radius:20px; color:var(--wheat); letter-spacing:0.3px; }

  /* PROJECTS */
  .projects-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(320px,1fr)); gap:1.5rem; }
  .project-card { background:var(--offwhite); border:1.5px solid var(--ivory); border-radius:22px; overflow:hidden; box-shadow:0 4px 20px rgba(46,58,47,0.07); transition:all 0.22s; display:flex; flex-direction:column; }
  .project-card:hover { transform:translateY(-6px); box-shadow:0 14px 40px rgba(46,58,47,0.13); border-color:var(--sage); }
  .project-banner { height:80px; display:flex; align-items:center; justify-content:center; font-size:36px; position:relative; overflow:hidden; }
  .project-banner::before { content:''; position:absolute; inset:0; background:inherit; filter:brightness(0.75); }
  .project-banner span { position:relative; z-index:1; filter:drop-shadow(2px 2px 0 rgba(0,0,0,0.25)); }
  .project-body { padding:1.5rem; flex:1; display:flex; flex-direction:column; }
  .project-company { font-family:'Press Start 2P',monospace; font-size:5.5px; color:var(--stone); letter-spacing:2px; margin-bottom:0.5rem; }
  .project-title { font-family:'Press Start 2P',monospace; font-size:8.5px; color:var(--dark); line-height:1.9; margin-bottom:0.75rem; }
  .project-desc { font-size:0.9rem; line-height:1.75; color:var(--muted); flex:1; margin-bottom:1rem; }
  .project-highlight { background:var(--grass); color:var(--cream); font-family:'Press Start 2P',monospace; font-size:6px; padding:6px 12px; border-radius:20px; display:inline-block; margin-bottom:0.75rem; line-height:1.7; }
  .project-tech-tag { font-family:'Press Start 2P',monospace; font-size:5.5px; padding:4px 10px; background:rgba(74,124,63,0.09); border:1px solid rgba(74,124,63,0.28); border-radius:20px; color:var(--moss); letter-spacing:0.3px; }

  /* EDUCATION */
  .edu-bg { background:linear-gradient(135deg,var(--sky) 0%,var(--sage) 60%,var(--grass) 100%); padding:5rem 0; }
  .edu-card { background:var(--fog); border:2px solid rgba(255,255,255,0.65); border-radius:26px; padding:2.5rem 3rem; box-shadow:0 12px 40px rgba(46,58,47,0.13); max-width:680px; margin:0 auto; display:grid; grid-template-columns:auto 1fr; gap:2rem; align-items:center; }
  .edu-icon { width:96px; height:96px; background:var(--dark); border:2px solid var(--hay); border-radius:22px; display:flex; align-items:center; justify-content:center; font-size:44px; box-shadow:0 6px 20px rgba(0,0,0,0.18); flex-shrink:0; }
  .edu-school { font-family:'Press Start 2P',monospace; font-size:9.5px; color:var(--dark); line-height:1.9; margin-bottom:0.5rem; }
  .edu-degree { font-family:'Crimson Pro',serif; font-size:1.2rem; color:var(--berry); font-style:italic; margin-bottom:0.5rem; }
  .edu-period { font-size:0.875rem; color:var(--moss); font-weight:700; }
  .cert-list { display:flex; flex-direction:column; gap:0.7rem; margin-top:2rem; align-items:flex-start; text-align:left; }
  .cert-item { background:rgba(249,245,236,0.92); border:1.5px solid rgba(255,255,255,0.6); border-left:5px solid var(--grass); border-radius:16px; padding:1rem 1.5rem; display:flex; align-items:center; gap:1rem; box-shadow:0 2px 10px rgba(46,58,47,0.07); transition:all 0.15s; width:100%; }
  .cert-item:hover { transform:translateX(5px); border-left-color:var(--hay); background:rgba(249,245,236,0.7); }
  .cert-icon { font-size:22px; flex-shrink:0; }
  .cert-name { font-family:'Press Start 2P',monospace; font-size:6.5px; color:var(--dark); line-height:1.9; }
  .cert-issuer { font-size:0.8rem; color:var(--muted); margin-top:0.2rem; }

  /* CONTACT */
  .social-bg { background:var(--moss); padding:5rem 0; }
  .social-bg .section-label { color:var(--sage); }
  .social-bg .section-title { color:var(--cream); }
  .social-bg .section-title::after { background:linear-gradient(90deg,var(--hay),var(--sage)); }
  .social-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:1rem; max-width:800px; margin:0 auto; }
  .social-card { background:rgba(255,255,255,0.08); border:1.5px solid rgba(255,255,255,0.14); border-radius:22px; padding:1.5rem; text-align:center; text-decoration:none; box-shadow:0 4px 16px rgba(0,0,0,0.14); transition:all 0.18s; display:flex; flex-direction:column; align-items:center; gap:0.65rem; }
  .social-card:hover { transform:translateY(-5px); box-shadow:0 10px 32px rgba(0,0,0,0.2); background:rgba(255,255,255,0.14); border-color:var(--hay); }
  .social-icon { font-size:30px; }
  .social-name { font-family:'Press Start 2P',monospace; font-size:5.5px; color:var(--hay); line-height:1.8; }
  .social-handle { font-size:0.7rem; color:rgba(232,224,208,0.8); }

  /* FOOTER */
  footer { background:var(--dark); border-top:3px solid var(--hay); padding:2rem; text-align:center; }
  .footer-text { font-family:'Press Start 2P',monospace; font-size:9px; color:var(--stone); line-height:2.2; }
  .footer-heart { color:var(--berry); }

  /* FLOATING LEAVES */
  .leaf-float { position:fixed; font-size:18px; pointer-events:none; animation:leafFall linear infinite; z-index:9998; opacity:0.5; }
  @keyframes leafFall { 0%{transform:translateY(-50px) rotate(0deg);opacity:0;} 10%{opacity:0.5;} 90%{opacity:0.3;} 100%{transform:translateY(110vh) rotate(720deg);opacity:0;} }

  /* RESPONSIVE */
  @media(max-width:768px){
    nav{padding:0 1rem;} .nav-links{display:none;}
    .hero-card{padding:2rem 1.5rem;border-radius:18px;}
    .about-grid{grid-template-columns:1fr;}
    .edu-card{grid-template-columns:1fr;text-align:center;}
    .edu-icon{margin:0 auto;}
    section{padding:3rem 1rem;}
    .hero-name{font-size:11px;}
  }
`;

const CDN = "https://cdn.jsdelivr.net/gh/devicons/devicon@latest/icons";
const SI  = "https://cdn.simpleicons.org";

const skills = {
  "Languages": [
    { name:"Java",       logo:`${CDN}/java/java-original.svg` },
    { name:"TypeScript", logo:`${CDN}/typescript/typescript-original.svg` },
    { name:"JavaScript", logo:`${CDN}/javascript/javascript-original.svg` },
    { name:"Go",         logo:`${CDN}/go/go-original.svg` },
    { name:"C#",         logo:`${CDN}/csharp/csharp-original.svg` },
    { name:"PHP",        logo:`${CDN}/php/php-original.svg` },
    { name:"Dart",       logo:`${CDN}/dart/dart-original.svg` },
    { name:"HTML",       logo:`${CDN}/html5/html5-original.svg` },
    { name:"CSS",        logo:`${CDN}/css3/css3-original.svg` },
  ],
  "Frameworks & Libraries": [
    { name:"Spring Boot", logo:`${CDN}/spring/spring-original.svg` },
    { name:"Quarkus",     logo:`${SI}/quarkus/EE503E` },
    { name:"NestJS",      logo:`${CDN}/nestjs/nestjs-original.svg` },
    { name:"Node.js",     logo:`${CDN}/nodejs/nodejs-original.svg` },
    { name:"React",       logo:`${CDN}/react/react-original.svg` },
    { name:"Flutter",     logo:`${CDN}/flutter/flutter-original.svg` },
    { name:"Laravel",     logo:`${CDN}/laravel/laravel-original.svg` },
    { name:"ASP.NET",     logo:`${CDN}/dotnetcore/dotnetcore-original.svg` },
  ],
  "Databases & Storage": [
    { name:"PostgreSQL",  logo:`${CDN}/postgresql/postgresql-original.svg` },
    { name:"MongoDB",     logo:`${CDN}/mongodb/mongodb-original.svg` },
    { name:"MySQL",       logo:`${CDN}/mysql/mysql-original.svg` },
    { name:"Oracle DB",   logo:`${CDN}/oracle/oracle-original.svg` },
    { name:"Redis",       logo:`${CDN}/redis/redis-original.svg` },
    { name:"IBM DB2",     logo:`${SI}/ibm/052FAD` },
    { name:"MinIO",       logo:`${SI}/minio/C72E49` },
  ],
  "DevOps & Infra": [
    { name:"Docker",        logo:`${CDN}/docker/docker-original.svg` },
    { name:"Jenkins",       logo:`${CDN}/jenkins/jenkins-original.svg` },
    { name:"Apache Kafka",  logo:`${SI}/apachekafka/231F20` },
    { name:"Elasticsearch", logo:`${SI}/elasticsearch/005571` },
    { name:"Kibana",        logo:`${SI}/kibana/005571` },
    { name:"NGINX",         logo:`${CDN}/nginx/nginx-original.svg` },
    { name:"Git",           logo:`${CDN}/git/git-original.svg` },
  ],
  "Project & Collaboration": [
    { name:"Jira",    logo:`${CDN}/jira/jira-original.svg` },
    { name:"ClickUp", logo:`${SI}/clickup/7B68EE` },
    { name:"Trello",  logo:`${CDN}/trello/trello-original.svg` },
  ],
};

const experiences = [
  {
    company:"PT. Code Development Indonesia", period:"Sep 2024 – Present",
    roles:[
      { title:"Backend Developer", client:"@ PT. Telkomsel", period:"Feb 2026 – Present",
        bullets:["Engineered an AI Biometric Facial Recognition system and AI-powered Travel Assistant for automated itinerary generation.","Utilized Redis for high-speed caching and session management, ensuring low-latency AI-driven responses.","Designed scalable MongoDB data models optimized for high-volume unstructured data and AI search results.","Built highly maintainable microservices architecture with NestJS.","Developed an enterprise CMS to manage merchant onboarding, transaction processing, and marketing campaigns.","Implemented robust security protocols (Pentest Approved) to protect sensitive data and ensure system integrity."],
        tech:["Node.js","NestJS","Redis","MongoDB","MinIO"] },
      { title:"Backend Developer", client:"@ PT. Asuransi Jasa Indonesia", period:"Aug 2025 – Feb 2026",
        bullets:["Engineered a Central Payment Service consolidating financial transactions for 5 internal enterprise systems.","Integrated Xendit Payment Gateway and Virtual Account infrastructure for automated payment processing.","Developed high-reliability Webhooks for real-time payment notifications with 100% transaction accuracy.","Optimized backend services using Java Spring Boot and IBM DB2 with ACID-compliant transactions."],
        tech:["Java","Spring Boot","IBM DB2","Xendit API","Webhooks"] },
      { title:"Backend Developer", client:"@ PT. Telkomsel", period:"Jul 2025 – Aug 2025",
        bullets:["Engineered a central monitoring dashboard for 200+ Centerm soundbox devices using Node.js.","Integrated Elasticsearch and Kibana for real-time log analysis and health visualization.","Designed high-availability storage using PostgreSQL and Redis.","Implemented RBAC and JWT for secure access controls."],
        tech:["Node.js","PostgreSQL","Redis","Elasticsearch","Kibana","JWT"] },
      { title:"Backend Developer", client:"@ PT. Prudential Life Assurance", period:"Sep 2024 – Jul 2025",
        bullets:["Developed backend servers using Quarkus and maintained legacy Spring Boot projects.","Built and optimized API gateways using NestJS and TypeScript.","Increased unit test coverage from 0% to 95%, drastically reducing production regressions.","Utilized Apache Kafka for asynchronous event-driven messaging."],
        tech:["Java","Quarkus","Spring Boot","NestJS","Kafka","JaCoCo","TypeScript"] },
    ],
  },
  {
    company:"PT. Mitra Integrasi Informatika", period:"Sep 2021 – Sep 2024",
    roles:[
      { title:"Fullstack Developer", client:"@ PT. Federal International Finance", period:"May 2022 – Sep 2024",
        bullets:["Achieved 95% improvement in system response time, reducing latency from 20s to under 1s.","Built and maintained 20+ system modules using MVVM pattern and ZK/Zkoss framework.","Delivered high-priority features within 3-week Sprints using Scrum methodology.","Performed unit testing with JUnit and managed full SDLC from development to UAT."],
        tech:["Java","Spring Boot","Oracle DB","ZK/Zkoss","JUnit","Scrum"] },
      { title:"Project Management Officer", client:"@ PT. Bank Negara Indonesia", period:"Nov 2021 – May 2022",
        bullets:["Managed timelines and delivery for IT and Banking Operational Support projects.","Coordinated meetings across multiple divisions to ensure project alignment.","Tracked project progress ensuring all milestones were met on schedule."],
        tech:["Trello","Project Management","Documentation"] },
    ],
  },
  {
    company:"PT Lawencon International", period:"May 2021 – Aug 2021",
    roles:[
      { title:"Programmer & QA Intern", client:"", period:"May 2021 – Aug 2021",
        bullets:["Developed automated test scripts using Katalon Studio to improve QA efficiency.","Executed unit testing and manual end-to-end testing for web and mobile applications.","Identified and documented software defects during active development phases."],
        tech:["Katalon Studio","QA Testing","Manual Testing"] },
    ],
  },
];

const projects = [
  { title:"AI Biometric & Travel Assistant", company:"PT. Telkomsel", period:"2026", icon:"🤖", color:"linear-gradient(135deg,#4A7C3F 0%,#5B8FA8 100%)", desc:"Engineered an AI-powered Facial Recognition system and a Travel Assistant that auto-generates personalized itineraries. Built with NestJS microservices and MongoDB.", highlight:"⚡ AI-Powered Features", tech:["Node.js","NestJS","MongoDB","Redis","MinIO"] },
  { title:"Content Management System", company:"PT. Telkomsel", period:"2026", icon:"🧰", color:"linear-gradient(135deg,#5B8FA8 0%,#D4A843 100%)", desc:"Enterprise backend API built with NestJS handling authentication, campaigns, attendance, and operations across 17+ modules. Features JWT, RBAC, MongoDB, Redis, MinIO storage, and complete Docker containerization.", highlight:"📦 17+ modules", tech:["NestJS","TypeScript","MongoDB","Redis","MinIO"] },
  { title:"Central Payment Service", company:"PT. Asuransi Jasa Indonesia", period:"2025–2026", icon:"💳", color:"linear-gradient(135deg,#7B5EA7 0%,#8B3A52 100%)", desc:"Consolidated financial transactions across 5 enterprise systems. Integrated Xendit Gateway and real-time webhooks achieving 100% transaction accuracy.", highlight:"✅ 100% Transaction Accuracy", tech:["Spring Boot","IBM DB2","Xendit","Webhooks"] },
  { title:"IoT Device Monitoring Dashboard", company:"PT. Telkomsel", period:"2025", icon:"📡", color:"linear-gradient(135deg,#5B8FA8 0%,#3D5E35 100%)", desc:"Built a centralized real-time dashboard monitoring 200+ Centerm soundbox devices, leveraging Elasticsearch and Kibana for fleet health visualization.", highlight:"📡 200+ Devices Monitored", tech:["Node.js","PostgreSQL","Elasticsearch","Kibana"] },
  { title:"API Gateway & Microservices Platform", company:"PT. Prudential Life Assurance", period:"2024–2025", icon:"🔀", color:"linear-gradient(135deg,#D4A843 0%,#4A7C3F 100%)", desc:"Architected enterprise API gateways with Quarkus and NestJS. Transformed testing culture from 0% to 95% unit test coverage with Kafka event-driven messaging.", highlight:"📈 0% to 95% Test Coverage", tech:["Quarkus","NestJS","Kafka","Spring Boot"] },
  { title:"Enterprise Loan Management System", company:"PT. Federal International Finance", period:"2022–2024", icon:"🏦", color:"linear-gradient(135deg,#8FBC6E 0%,#3D5E35 100%)", desc:"Developed 20+ core web application modules for a major financial institution. Achieved 95% improvement in response time, dropping latency from 20s to under 1 second.", highlight:"🚀 20s to under 1s Response Time", tech:["Spring Boot","Oracle DB","ZK/Zkoss","JUnit"] },
];

const leaves = ["🍃","🍂","🌿","🍁"];

export default function Portfolio() {
  const [activeSection, setActiveSection] = useState("home");
  const [leafEls, setLeafEls] = useState([]);
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', body: '' });

  const handleSubmit = (e) => {
    e.preventDefault();
    const { name, email, subject, body } = formData;
    emailjs.send('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', {
      from_name: name,
      from_email: email,
      subject: subject,
      message: body,
    }, 'YOUR_USER_ID')
    .then((result) => {
      console.log(result.text);
      alert('Message sent successfully!');
      setFormData({ name: '', email: '', subject: '', body: '' });
    }, (error) => {
      console.log(error.text);
      alert('Failed to send message.');
    });
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  useEffect(() => {
    setLeafEls(Array.from({length:7},(_,i)=>({
      id:i, emoji:leaves[i%leaves.length],
      left:Math.random()*100,
      delay:Math.random()*12,
      duration:9+Math.random()*8,
    })));
  }, []);

  useEffect(() => {
    const handler = () => {
      const ids = ["home","about","skills","experience","projects","education","contact"];
      for (const id of ids) {
        const el = document.getElementById(id);
        if (el) { const r = el.getBoundingClientRect(); if (r.top<=100&&r.bottom>=100){setActiveSection(id);break;} }
      }
    };
    window.addEventListener("scroll",handler);
    return ()=>window.removeEventListener("scroll",handler);
  }, []);

  return (
    <>
      <style>{style}</style>
      {leafEls.map(l=>(
        <div key={l.id} className="leaf-float" style={{left:`${l.left}%`,animationDelay:`${l.delay}s`,animationDuration:`${l.duration}s`}}>{l.emoji}</div>
      ))}

      {/* NAV */}
      <nav>
        <div className="nav-logo">🌾CAKRYUDHA🌾</div>
        <ul className="nav-links">
          {[["home","🏠"],["about","👤"],["skills","⚔️"],["experience","📜"],["projects","🌾"],["education","🎓"],["contact","📬"]].map(([s,ic])=>(
            <li key={s}><a href={`#${s}`} className={activeSection===s?"active":""}><span style={{fontSize:"18px"}}>{ic}</span> {s.toUpperCase()}</a></li>
          ))}
        </ul>
      </nav>

      {/* HERO */}
      <div id="home" className="hero">
        <div className="hero-sun"/>
        {[{w:120,h:40,top:10,dur:36},{w:80,h:28,top:20,dur:50},{w:160,h:48,top:8,dur:29},{w:100,h:34,top:30,dur:44}].map((c,i)=>(
          <div key={i} className="cloud" style={{width:c.w,height:c.h,top:`${c.top}%`,left:`-${c.w}px`,animationDuration:`${c.dur}s`,animationDelay:`${i*7}s`,boxShadow:`${c.w*.3}px 0 0 ${c.w*.3}px rgba(255,255,255,0.88),${c.w*.5}px -${c.h*.3}px 0 ${c.h*.1}px rgba(255,255,255,0.7)`}}/>
        ))}
        {[{l:3,s:68},{l:8,s:50},{l:86,s:62},{l:92,s:78},{l:97,s:44}].map((t,i)=>(
          <div key={i} className="tree" style={{left:`${t.l}%`,bottom:"18%"}}>
            <div className="tree-top" style={{borderLeftWidth:t.s*.5,borderRightWidth:t.s*.5,borderBottomWidth:t.s*.7,borderBottomColor:i%2===0?"#3D5E35":"#4A7C3F"}}/>
            <div className="tree-top" style={{borderLeftWidth:t.s*.4,borderRightWidth:t.s*.4,borderBottomWidth:t.s*.6,marginTop:-t.s*.2,borderBottomColor:i%2===0?"#4A7C3F":"#6BAB5E"}}/>
            <div className="tree-trunk" style={{width:t.s*.2,height:t.s*.4}}/>
          </div>
        ))}
        <div style={{position:"absolute",bottom:0,left:0,right:0,height:"20%",background:"linear-gradient(180deg,var(--grass) 0%,var(--moss) 40%,var(--dark) 100%)"}}/>
        <div className="hero-content">
          <div className="hero-card">
            <h1 className="hero-name">CAKRAYUDHA KUSUMA ADI</h1>
            <p className="hero-role">Backend Developer | Fullstack Developer</p>
            <p className="hero-summary">5+ years building high-performance microservices & APIs with Java, Node.js, and NestJS. From fintech to telco — I grow systems that scale.</p>
            <div className="hero-btns">
              <a href="https://drive.google.com/file/d/1l6AxEN239Y-ZrUrqtXFFvewFm_8ObdvC/view?usp=sharing" className="btn btn-primary" target="_blank">⬇️ Download Resume</a>
              <a href="#projects" className="btn btn-secondary">🌾 See My Work</a>
              <a href="#contact" className="btn btn-tertiary">📬 Get In Touch</a>
            </div>
          </div>
        </div>
        <div className="scroll-hint"><span>SCROLL</span><span>▼</span></div>
      </div>

      {/* ABOUT */}
      <section id="about">
        <div className="section-header">
          <span className="section-label">✦ WHO AM I ✦</span>
          <h2 className="section-title">PROFESSIONAL SUMMARY</h2>
        </div>
        <div className="about-grid">
          <div className="about-card">
            <div className="avatar-frame">👨‍💻</div>
            <div className="about-name-card">
              <h2>CAKRAYUDHA KUSUMA ADI</h2>
              <p>Backend Developer | Fullstack Developer</p>
            </div>
            <ul className="stat-list">
              <li className="stat-item"><span className="stat-icon">📍</span>Bandung, West Java, Indonesia</li>
              <li className="stat-item"><span className="stat-icon">📧</span><a href="mailto:cakrayudha.adi@gmail.com">cakrayudha.adi@gmail.com</a></li>
              <li className="stat-item"><span className="stat-icon">📱</span>+62 857-7118-8754</li>
              <li className="stat-item"><span className="stat-icon">💼</span><a href="https://www.linkedin.com/in/cakrayudha" target="_blank" rel="noreferrer">LinkedIn Profile</a></li>
              <li className="stat-item"><span className="stat-icon">🐙</span><a href="https://github.com/cakrayudhaadi" target="_blank" rel="noreferrer">GitHub Profile</a></li>
              <li className="stat-item"><span className="stat-icon">🌏</span>Open to Work Remotely</li>
            </ul>
          </div>
          <div className="about-text">
            <p>Hey there! I'm a <strong>Backend Developer with 5+ years of experience</strong> specializing in building scalable microservices and high-performance API orchestration. I've cultivated my craft across fintech, telecommunications, and insurance industries.</p>
            <p>I work fluently in <strong>Java (Spring Boot, Quarkus), Node.js, and NestJS</strong>, managing complex data environments across PostgreSQL, MongoDB, and IBM DB2, while leveraging Kafka, Redis, and Elasticsearch to grow reliable systems.</p>
            <p>I'm a <strong>proactive collaborator</strong> in cross-functional teams who adapts quickly to new technologies. Currently looking for remote opportunities in the US or Europe!</p>
            <div className="xp-bars">
              <span className="xp-label">⚔️ SKILL LEVELS</span>
              {[{name:"Backend Dev",pct:95},{name:"Java / JVM",pct:93},{name:"Databases",pct:90},{name:"Node / TS",pct:88},{name:"DevOps",pct:72}].map(({name,pct})=>(
                <div key={name} className="xp-row">
                  <span className="xp-name">{name}</span>
                  <div className="xp-track"><div className="xp-fill" style={{width:`${pct}%`}}/></div>
                  <span className="xp-pct">{pct}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <div className="field-divider"/>

      {/* SKILLS */}
      <div id="skills" className="skills-bg">
        <div className="section-inner">
          <div className="section-header">
            <span className="section-label">✦ TOOLS & WEAPONS ✦</span>
            <h2 className="section-title">THE SKILL SHED</h2>
          </div>
          {Object.entries(skills).map(([cat,items])=>(
            <div key={cat}>
              <div className="skill-category-title">▸ {cat}</div>
              <div className="skills-row">
                {items.map(s=>(
                  <div key={s.name} className="skill-pill">
                    <img src={s.logo} alt={s.name} onError={e=>{e.target.style.display="none";}}/>
                    <span className="skill-pill-name">{s.name}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="field-divider" style={{transform:"scaleX(-1)"}}/>

      {/* EXPERIENCE */}
      <div id="experience" className="exp-bg">
        <div className="section-inner">
          <div className="section-header">
            <span className="section-label">✦ CAREER HISTORY ✦</span>
            <h2 className="section-title">THE CAREER LEDGER</h2>
          </div>
          <div className="timeline">
            {experiences.map((exp,ei)=>(
              <div key={ei} className="company-block">
                <div className="company-header">
                  <div className="company-name">{exp.company}</div>
                  <div className="company-period">{exp.period}</div>
                </div>
                <div className="role-cards">
                  {exp.roles.map((role,ri)=>(
                    <div key={ri} className="role-card">
                      <div className="role-title">{role.title}</div>
                      {role.client&&<div className="role-client">{role.client} · {role.period}</div>}
                      <ul className="role-bullets">{role.bullets.map((b,bi)=><li key={bi}>{b}</li>)}</ul>
                      <div className="tech-tags">{role.tech.map(t=><span key={t} className="tech-tag">{t}</span>)}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* PROJECTS */}
      <section id="projects">
        <div className="section-header">
          <span className="section-label">✦ WHAT I'VE BUILT ✦</span>
          <h2 className="section-title">THE PROJECTS</h2>
        </div>
        <div className="projects-grid">
          {projects.map((p,i)=>(
            <div key={i} className="project-card">
              <div className="project-banner" style={{background:p.color}}><span>{p.icon}</span></div>
              <div className="project-body">
                <div className="project-company">{p.company} · {p.period}</div>
                <div className="project-title">{p.title}</div>
                <p className="project-desc">{p.desc}</p>
                <div className="project-highlight">{p.highlight}</div>
                <div className="tech-tags">{p.tech.map(t=><span key={t} className="project-tech-tag">{t}</span>)}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* EDUCATION */}
      <div id="education" className="edu-bg">
        <div className="section-inner">
          <div className="section-header">
            <span className="section-label">✦ KNOWLEDGE BASE ✦</span>
            <h2 className="section-title">EDUCATION</h2>
          </div>
          <div className="edu-card">
            <div className="edu-icon">🎓</div>
            <div>
              <div className="edu-school">BANDUNG INSTITUTE OF TECHNOLOGY (ITB)</div>
              <div className="edu-degree">Bachelor of Science, Mathematics</div>
              <div className="edu-period">📅 June 2017 – July 2021</div>
            </div>
          </div>
          <div style={{maxWidth:680,margin:"3rem auto 0"}}>
            <div className="section-header" style={{marginBottom:"1.5rem"}}><span className="section-title">CERTIFICATIONS</span></div>
            <div className="cert-list">
              {[{icon:"🐹",name:"Backend Development with Golang",issuer:"Sanbercode · 2025",link:"https://sanbercode.com/certificate/in/a5fac4ee-2f11-4e14-a29b-8d17d0b6f629"},{icon:"☕",name:"The Complete Java Certification Course",issuer:"Udemy · 2025",link:"https://www.udemy.com/certificate/UC-265dd646-2136-4ed4-89b4-3d0aba0922e9/"},{icon:"🔒",name:"Security Awareness",issuer:"PT. FIFGROUP · 2024",link:"https://drive.google.com/drive/folders/1DXuGYq83-4ZvWT_b4l9qUZDtxbpd0VIB?usp=sharing"}].map((c,i)=>(
                c.link ? (
                  <a key={i} href={c.link} target="_blank" rel="noreferrer" className="cert-item" style={{textDecoration:'none', color:'inherit'}}>
                    <span className="cert-icon">{c.icon}</span>
                    <div><div className="cert-name">{c.name}</div><div className="cert-issuer">{c.issuer}</div></div>
                  </a>
                ) : (
                  <div key={i} className="cert-item">
                    <span className="cert-icon">{c.icon}</span>
                    <div><div className="cert-name">{c.name}</div><div className="cert-issuer">{c.issuer}</div></div>
                  </div>
                )
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* CONTACT */}
      <div id="contact" className="social-bg">
        <div className="section-inner">
          <div className="section-header">
            <span className="section-label">✦ LET'S CONNECT ✦</span>
            <h2 className="section-title">SEND A LETTER</h2>
          </div>
          <p style={{textAlign:"center",color:"var(--sage)",fontFamily:"'Crimson Pro',serif",fontSize:"1.2rem",fontStyle:"italic",marginBottom:"2.5rem"}}>Open to remote opportunities in around the world 🌍</p>
          <div className="social-grid">
            {[{href:"mailto:cakrayudha.adi@gmail.com",icon:"📧",name:"EMAIL",handle:"cakrayudha.adi@gmail.com"},{href:"https://www.linkedin.com/in/cakrayudha",icon:"💼",name:"LINKEDIN",handle:"linkedin.com/in/cakrayudha"},{href:"https://github.com/cakrayudhaadi",icon:"🐙",name:"GITHUB",handle:"github.com/cakrayudha"},{href:"tel:+6285771188754",icon:"📱",name:"PHONE",handle:"+62 857-7118-8754"}].map((s,i)=>(
              <a key={i} href={s.href} target={s.href.startsWith("http")?"_blank":undefined} rel="noreferrer" className="social-card">
                <span className="social-icon">{s.icon}</span>
                <span className="social-name">{s.name}</span>
                <span className="social-handle">{s.handle}</span>
              </a>
            ))}
          </div>
          {/* <div style={{marginTop:"3rem", textAlign:"center", maxWidth:"600px", margin:"3rem auto 0"}}>
            <form onSubmit={handleSubmit} style={{background:"rgba(255,255,255,0.08)", border:"1.5px solid rgba(212,168,67,0.55)", borderRadius:24, padding:"2rem", boxShadow:"0 6px 24px rgba(0,0,0,0.18)"}}>
              <div style={{marginBottom:"1rem", textAlign:"left"}}>
                <label style={{display:"block", marginBottom:"0.4rem", fontSize:"0.6rem", color:"var(--cream)", fontFamily:"'Press Start 2P',monospace", letterSpacing:"1px"}}>Your Name</label>
                <input type="text" name="name" value={formData.name} onChange={handleChange} required style={{width:"100%", padding:"0.75rem", borderRadius:"8px", border:"1px solid rgba(255,255,255,0.3)", background:"rgba(255,255,255,0.1)", color:"var(--cream)", fontSize:"1rem"}} />
              </div>
              <div style={{marginBottom:"1rem", textAlign:"left"}}>
                <label style={{display:"block", marginBottom:"0.4rem", fontSize:"0.6rem", color:"var(--cream)", fontFamily:"'Press Start 2P',monospace", letterSpacing:"1px"}}>Your Email</label>
                <input type="email" name="email" value={formData.email} onChange={handleChange} required style={{width:"100%", padding:"0.75rem", borderRadius:"8px", border:"1px solid rgba(255,255,255,0.3)", background:"rgba(255,255,255,0.1)", color:"var(--cream)", fontSize:"1rem"}} />
              </div>
              <div style={{marginBottom:"1rem", textAlign:"left"}}>
                <label style={{display:"block", marginBottom:"0.4rem", fontSize:"0.6rem", color:"var(--cream)", fontFamily:"'Press Start 2P',monospace", letterSpacing:"1px"}}>Subject</label>
                <input type="text" name="subject" value={formData.subject} onChange={handleChange} required style={{width:"100%", padding:"0.75rem", borderRadius:"8px", border:"1px solid rgba(255,255,255,0.3)", background:"rgba(255,255,255,0.1)", color:"var(--cream)", fontSize:"1rem"}} />
              </div>
              <div style={{marginBottom:"1.5rem", textAlign:"left"}}>
                <label style={{display:"block", marginBottom:"0.4rem", fontSize:"0.6rem", color:"var(--cream)", fontFamily:"'Press Start 2P',monospace", letterSpacing:"1px"}}>Your Message</label>
                <textarea name="body" value={formData.body} onChange={handleChange} required rows="5" style={{width:"100%", padding:"0.75rem", borderRadius:"8px", border:"1px solid rgba(255,255,255,0.3)", background:"rgba(255,255,255,0.1)", color:"var(--cream)", fontSize:"1rem", resize:"vertical"}} />
              </div>
              <button type="submit" className="btn btn-primary" style={{width:"100%", fontSize:"0.8rem", padding:"0.75rem"}}>📬 Send Message</button>
            </form>
          </div> */}
          <div style={{marginTop:"3rem",textAlign:"center", margin:"3rem auto 0"}}>
            <div style={{display:"inline-flex",alignItems:"center",gap:"0.85rem",background:"rgba(255,255,255,0.1)",border:"1.5px solid rgba(212,168,67,0.55)",borderRadius:24,padding:"1rem 2rem",boxShadow:"0 6px 24px rgba(0,0,0,0.18)"}}>
              <span style={{fontSize:26}}>🌱</span>
              <div>
                <div style={{fontFamily:"'Press Start 2P',monospace",fontSize:7,color:"var(--hay)",marginBottom:4,lineHeight:1.9}}>AVAILABLE FOR HIRE</div>
                <div style={{fontSize:"0.83rem",color:"var(--sage)"}}>Remote | Full-time · Contract · Freelance</div>
              </div>
              <span style={{width:11,height:11,background:"#6BCB77",borderRadius:"50%",boxShadow:"0 0 0 3px rgba(107,203,119,0.35)",animation:"sunPulse 2s ease-in-out infinite",flexShrink:0,display:"inline-block"}}/>
            </div>
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <footer>
        <div className="footer-text">
          🌾 HAND-CRAFTED WITH ❤️ BY CAKRAYUDHA KUSUMA ADI · 2026 🌾<br/><br/>
          BUILT WITH REACT · INSPIRED BY STARDEW VALLEY
        </div>
      </footer>
    </>
  );
}
